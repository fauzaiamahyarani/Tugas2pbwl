<?php
    session_start();

    define ('URL', 'http://localhost/fauzia/');
    define ('ASSET', URL . 'assets/');


    require_once "vendor/autoload.php";